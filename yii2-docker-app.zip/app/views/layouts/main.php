<!DOCTYPE html>
<html>
<head>
    <title>Yii2 App</title>
</head>
<body>
    <?= $content ?>
</body>
</html>