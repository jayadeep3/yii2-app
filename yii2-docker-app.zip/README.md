# Yii2 Docker Swarm Deployment
This project deploys a Yii2 application using Docker Swarm and Ansible.